/*
 * Author: Matejka Jiri
 * login:  xmatej52
 * school: VUT FIT
 * date:   22. 4. 2017
 * content: Implementation of hidden deck.
 */
package src.game;
import src.game.Card_stack;

/**
 * Class representing deck of hidden cards.
 * @author Matejka Jiri (xmatej52)
 */
public class Card_deck_hidden extends Card_stack{}