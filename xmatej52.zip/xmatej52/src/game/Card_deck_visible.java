/*
 * Author: Matejka Jiri
 * login:  xmatej52
 * school: VUT FIT
 * date:   22. 4. 2017
 * content: Implementation of visible deck.
 */
package src.game;
import src.game.Card_stack;

/**
 * Class representing deck of visible cards
 * @author Matejka Jiri (xmatej52)
 */
public class Card_deck_visible extends Card_stack {}