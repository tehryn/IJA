#!/usr/bin/env bash

wget www.stud.fit.vutbr.cz/~xmatej52/cards.zip
unzip cards.zip
